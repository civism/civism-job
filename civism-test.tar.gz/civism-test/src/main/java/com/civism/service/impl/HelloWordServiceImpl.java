package com.civism.service.impl;

import com.civism.job.GuavaJob;
import com.civism.service.HelloWordService;
import org.springframework.stereotype.Service;

/**
 * @author star
 * @date 2018/1/29 上午11:52
 */


@GuavaJob(value = "com.ruhnn.service.impl.HelloWordServiceImpl")
@Service
public class HelloWordServiceImpl implements HelloWordService {

    @Override
    public String sayHello() {
        System.out.println("hello guava");
        return "hello";
    }

    @Override
    public String say() {
        System.out.println("say#######");
        return "hello";
    }


    @Override
    public String sayHello(Integer share, Integer total) {
        System.out.println("share=" + share + "total=" + total);
        return "shareTotal";
    }


    @Override
    public String sayHello(String hello, Integer num) {
        System.out.println("hello" + hello + "num:" + num);
        return "welcome";
    }
}
