package com.civism.service;

/**
 * @author star
 * @date 2018/1/29 上午11:52
 */
public interface HelloWordService {
    String sayHello();

    String say();

    String sayHello(Integer share, Integer total);

    String sayHello(String hello, Integer num);
}
